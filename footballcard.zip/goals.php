﻿<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    
    <title>Search By dates</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
	<link href="css/coming-sssoon.css" rel="stylesheet" />    
    
    <!--     Fonts     -->
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
  
</head>

<body>
<nav class="navbar navbar-transparent navbar-fixed-top" role="navigation">  
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
      <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="#"> 
                    <i class="fa fa-facebook-square"></i>
                    Share
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-twitter"></i>
                    Tweet
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-envelope-o"></i>
                    Email
                </a>
            </li>
       </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
<div class="main" style="background-image: url('images/default.jpg')">

<!--    Change the image source '/images/default.jpg' with your favourite image.     -->
    
    <div class="cover black" data-color="black"></div>
     
<!--   You can change the black color for the filter with those colors: blue, green, red, orange       -->

    <div class="container">
        <h1 class="logo cursive">
            Football Lovers
        </h1>
<!--  H1 can have 2 designs: "logo" and "logo cursive"           -->
        
        <div class="content">
        		<div style="width:500px; margin:auto; text-align:center;">
			<form action="goalsaction.php" method="get">
			<select name="team" required style="width:450px; height:50px; padding:10px; margin:10px;">
					<option>Scotland</option>
					<option>England</option>
					<option>Wales</option>
					<option>Northern Ireland</option>
					<option>United States</option>
					<option>Uruguay</option>
					<option>Austria</option>
					<option>Hungary</option>
					<option>Argentina</option>
					<option>Belgium</option>
					<option>France</option>
					<option>Netherlands</option>
					<option>Czechoslovakia</option>
					<option>Switzerland</option>
					<option>Sweden</option>
					<option>Germany</option>
					<option>Italy</option>
					<option>Chile</option>
					<option>Norway</option>
					<option>Finland</option>
					<option>Luxembourg</option>
					<option>Russia</option>
					<option>Denmark</option>
					<option>Catalonia</option>
					<option>Basque Country</option>
					<option>Brazil</option>
					<option>Japan</option>
					<option>Paraguay</option>
					<option>Canada</option>
					<option>Estonia</option>
					<option>Costa Rica</option>
					<option>Guatemala</option>
					<option>Spain</option>
					<option>Brittany</option>
					<option>Poland</option>
					<option>Yugoslavia</option>
					<option>New Zealand</option>
					<option>Romania</option>
					<option>Latvia</option>
					<option>Galicia</option>
					<option>Portugal</option>
					<option>Andalusia</option>
					<option>China PR</option>
					<option>Australia</option>
					<option>Lithuania</option>
					<option>Turkey</option>
					<option>Central Spain</option>
					<option>Mexico</option>
					<option>Aruba</option>
					<option>Egypt</option>
					<option>Haiti</option>
					<option>Philippines</option>
					<option>Bulgaria</option>
					<option>Jamaica</option>
					<option>Kenya</option>
					<option>Bolivia</option>
					<option>Peru</option>
					<option>Honduras</option>
					<option>Guyana</option>
					<option>Uganda</option>
					<option>Belarus</option>
					<option>El Salvador</option>
					<option>Barbados</option>
					<option>Republic of Ireland</option>
					<option>Trinidad and Tobago</option>
					<option>Greece</option>
					<option>CuraÃ§ao</option>
					<option>Dominica</option>
					<option>Silesia</option>
					<option>Guadeloupe</option>
					<option>Israel</option>
					<option>Suriname</option>
					<option>French Guiana</option>
					<option>Cuba</option>
					<option>Colombia</option>
					<option>Ecuador</option>
					<option>Saint Kitts and Nevis</option>
					<option>Panama</option>
					<option>Slovakia</option>
					<option>Manchukuo</option>
					<option>Croatia</option>
					<option>Nicaragua</option>
					<option>Afghanistan</option>
					<option>India</option>
					<option>Martinique</option>
					<option>Zimbabwe</option>
					<option>Iceland</option>
					<option>Albania</option>
					<option>Madagascar</option>
					<option>Zambia</option>
					<option>Mauritius</option>
					<option>Tanzania</option>
					<option>Iran</option>
					<option>Djibouti</option>
					<option>DR Congo</option>
					<option>Vietnam</option>
					<option>Macau</option>
					<option>Ethiopia</option>
					<option>Puerto Rico</option>
					<option>RÃ©union</option>
					<option>Sierra Leone</option>
					<option>Zanzibar</option>
					<option>South Korea</option>
					<option>Ghana</option>
					<option>South Africa</option>
					<option>New Caledonia</option>
					<option>Fiji</option>
					<option>Nigeria</option>
					<option>Venezuela</option>
					<option>Myanmar</option>
					<option>Sri Lanka</option>
					<option>Tahiti</option>
					<option>Gambia</option>
					<option>Hong Kong</option>
					<option>Singapore</option>
					<option>Malaysia</option>
					<option>Indonesia</option>
					<option>Guinea-Bissau</option>
					<option>German DR</option>
					<option>Vanuatu</option>
					<option>Kernow</option>
					<option>Saarland</option>
					<option>Cambodia</option>
					<option>Lebanon</option>
					<option>Pakistan</option>
					<option>Vietnam Republic</option>
					<option>North Korea</option>
					<option>Togo</option>
					<option>Sudan</option>
					<option>Malta</option>
					<option>Syria</option>
					<option>Tunisia</option>
					<option>Malawi</option>
					<option>Morocco</option>
					<option>Benin</option>
					<option>Cameroon</option>
					<option>Central African Republic</option>
					<option>Gabon</option>
					<option>Ivory Coast</option>
					<option>Congo</option>
					<option>Mali</option>
					<option>North Vietnam</option>
					<option>Mongolia</option>
					<option>Taiwan</option>
					<option>Cyprus</option>
					<option>Iraq</option>
					<option>Saint Lucia</option>
					<option>Grenada</option>
					<option>Thailand</option>
					<option>Senegal</option>
					<option>Libya</option>
					<option>Guinea</option>
					<option>Algeria</option>
					<option>Kuwait</option>
					<option>Jordan</option>
					<option>Solomon Islands</option>
					<option>Liberia</option>
					<option>Laos</option>
					<option>Saint Vincent and the Grenadines</option>
					<option>Bermuda</option>
					<option>Niger</option>
					<option>Bahrain</option>
					<option>Montenegro</option>
					<option>Palestine</option>
					<option>Papua New Guinea</option>
					<option>Burkina Faso</option>
					<option>Mauritania</option>
					<option>Saudi Arabia</option>
					<option>Eswatini</option>
					<option>Western Australia</option>
					<option>Somalia</option>
					<option>Lesotho</option>
					<option>Cook Islands</option>
					<option>Qatar</option>
					<option>Antigua and Barbuda</option>
					<option>Faroe Islands</option>
					<option>Bangladesh</option>
					<option>Oman</option>
					<option>Yemen DPR</option>
					<option>Burundi</option>
					<option>Yemen</option>
					<option>Mozambique</option>
					<option>Guam</option>
					<option>Chad</option>
					<option>Angola</option>
					<option>Dominican Republic</option>
					<option>Seychelles</option>
					<option>Rwanda</option>
					<option>SÃ£o TomÃ© and PrÃ­ncipe</option>
					<option>Botswana</option>
					<option>Northern Cyprus</option>
					<option>Cape Verde</option>
					<option>Kyrgyzstan</option>
					<option>Georgia</option>
					<option>Azerbaijan</option>
					<option>Kiribati</option>
					<option>Tonga</option>
					<option>Wallis Islands and Futuna</option>
					<option>United Arab Emirates</option>
					<option>Brunei</option>
					<option>Equatorial Guinea</option>
					<option>Liechtenstein</option>
					<option>Nepal</option>
					<option>Greenland</option>
					<option>Niue</option>
					<option>Samoa</option>
					<option>American Samoa</option>
					<option>Belize</option>
					<option>Anguilla</option>
					<option>Cayman Islands</option>
					<option>Palau</option>
					<option>Sint Maarten</option>
					<option>Namibia</option>
					<option>Ã…land Islands</option>
					<option>Ynys MÃ´n</option>
					<option>Saint Martin</option>
					<option>San Marino</option>
					<option>Slovenia</option>
					<option>Jersey</option>
					<option>Shetland</option>
					<option>Isle of Wight</option>
					<option>Moldova</option>
					<option>Ukraine</option>
					<option>Kazakhstan</option>
					<option>Tajikistan</option>
					<option>Uzbekistan</option>
					<option>Turkmenistan</option>
					<option>Armenia</option>
					<option>Czech Republic</option>
					<option>Guernsey</option>
					<option>Gibraltar</option>
					<option>Isle of Man</option>
					<option>North Macedonia</option>
					<option>Montserrat</option>
					<option>Serbia</option>
					<option>Canary Islands</option>
					<option>Bosnia and Herzegovina</option>
					<option>Maldives</option>
					<option>Andorra</option>
					<option>British Virgin Islands</option>
					<option>FrÃ¸ya</option>
					<option>Hitra</option>
					<option>United States Virgin Islands</option>
					<option>Corsica</option>
					<option>Eritrea</option>
					<option>Bahamas</option>
					<option>Gotland</option>
					<option>Saare County</option>
					<option>Rhodes</option>
					<option>Micronesia</option>
					<option>Bhutan</option>
					<option>Orkney</option>
					<option>Monaco</option>
					<option>Tuvalu</option>
					<option>Sark</option>
					<option>Alderney</option>
					<option>Mayotte</option>
					<option>Turks and Caicos Islands</option>
					<option>East Timor</option>
					<option>Western Isles</option>
					<option>Falkland Islands</option>
					<option>Kosovo</option>
					<option>Republic of St. Pauli</option>
					<option>GÄƒgÄƒuzia</option>
					<option>Tibet</option>
					<option>Occitania</option>
					<option>SÃ¡pmi</option>
					<option>Northern Mariana Islands</option>
					<option>Menorca</option>
					<option>Comoros</option>
					<option>Provence</option>
					<option>Arameans Suryoye</option>
					<option>Padania</option>
					<option>Iraqi Kurdistan</option>
					<option>Gozo</option>
					<option>Bonaire</option>
					<option>Western Sahara</option>
					<option>Raetia</option>
					<option>Darfur</option>
					<option>Tamil Eelam</option>
					<option>South Sudan</option>
					<option>Abkhazia</option>
					<option>Saint Pierre and Miquelon</option>
					<option>Artsakh</option>
					<option>Madrid</option>
					<option>Vatican City</option>
					<option>Ellan Vannin</option>
					<option>South Ossetia</option>
					<option>County of Nice</option>
					<option>SzÃ©kely Land</option>
					<option>Romani people</option>
					<option>FelvidÃ©k</option>
					<option>Chagos Islands</option>
					<option>United Koreans in Japan</option>
					<option>Somaliland</option>
					<option>Western Armenia</option>
					<option>Barawa</option>
					<option>KÃ¡rpÃ¡talja</option>
					<option>Yorkshire</option>
					<option>Panjab</option>
					<option>Matabeleland</option>
					<option>Cascadia</option>
					<option>Kabylia</option>
					<option>Timor-Leste</option>
					<option>Parishes of Jersey</option>
					<option>Chameria</option>
					<option>Saint Helena</option>
			</select>
		<input style="width:250px; height:50px; padding:10px; margin:10px; border:thin; background-color:#fff; color:#434343;" type="submit" value="Find Matches">
			</form>
			</div>
 </div>

        </div>
    </div>
    <div class="footer">
      <div class="container">
             Made with <i class="fa fa-heart heart"></i> by <a href="www.googlit.tech">Majdi Awad</a>.      </div>
    </div>
 </div>
 </body>
   <script src="js/jquery-1.10.2.js" type="text/javascript"></script>
   <script src="js/bootstrap.min.js" type="text/javascript"></script>

</html>