<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    
    <title>Search By Teams</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
	<link href="css/coming-sssoon.css" rel="stylesheet" />    
    
    <!--     Fonts     -->
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
  
</head>

<body>
<nav class="navbar navbar-transparent navbar-fixed-top" role="navigation">  
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
      <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="#"> 
                    <i class="fa fa-facebook-square"></i>
                    Share
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-twitter"></i>
                    Tweet
                </a>
            </li>
             <li>
                <a href="#"> 
                    <i class="fa fa-envelope-o"></i>
                    Email
                </a>
            </li>
       </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
<div class="main" style="background-image: url('images/default.jpg')">

<!--    Change the image source '/images/default.jpg' with your favourite image.     -->
    
    <div class="cover black" data-color="black"></div>
     
<!--   You can change the black color for the filter with those colors: blue, green, red, orange       -->

    <div class="container">
        <h1 class="logo cursive">
            Football Lovers
        </h1>
<!--  H1 can have 2 designs: "logo" and "logo cursive"           -->
        
        <div class="content">
        	<div style="width:500px; margin:auto; text-align:center;">
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "football";

$conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        
        die("connection failed: " . $conn->connect_error);
    }

    if(isset($_GET['team'])) {
        
        $home_team = $_GET['team'];
		$away_team = $_GET['team'];
		
        $query = $conn->query("SELECT * FROM football WHERE home_team = '$home_team' AND home_score > away_score");
        $query2 = $conn->query("SELECT * FROM football WHERE away_team = '$away_team' AND home_score < away_score");
        $lose = $conn->query("SELECT * FROM football WHERE home_team = '$home_team' AND home_score < away_score");
        $lose2 = $conn->query("SELECT * FROM football WHERE away_team = '$away_team' AND home_score > away_score");
        $equality = $conn->query("SELECT * FROM football WHERE home_team = '$home_team' AND home_score = away_score");
		$max1 = $conn->query("SELECT MAX(home_score) AS max1 FROM football WHERE home_team = '$home_team'");
		$max2 = $conn->query("SELECT MAX(away_score) AS max2  FROM football WHERE away_team = '$away_team'");


        ?>
        <div style="color:#fff; font-size:xx-large;"><?php echo $home_team; ?></div><br><br>        
        <div style="color:#fff;">MATCHES WON: <?php echo $query->num_rows + $query2->num_rows; ?><br><br>        
        <div style="color:#fff;">MATCHES LOSE: <?php echo $lose->num_rows + $lose2->num_rows; ?><br><br>        
        <div style="color:#fff;">MATCHES EQUALITY: <?php echo $equality->num_rows; ?><br><br>        
		<div style="color:#fff;">MAX NUMBER OF GOALS IN ONE MATCH: <?php 
		$r = mysqli_fetch_assoc($max1);
		$max1 = $r['max1'];
		$row = mysqli_fetch_assoc($max2);
		$max2 = $row['max2'];

		if($max1 > $max2) {
		
			echo $max1;
				
				} else {
				
						echo $max2;
						
						}	
 ?>
<br><br>        

        <?php


        }
 
?>
			</div>
 </div>

        </div>
    </div>
    <div class="footer">
      <div class="container">
             Made with <i class="fa fa-heart heart"></i> by <a href="www.googlit.tech">Majdi Awad</a>.      </div>
    </div>
 </div>
 </body>
   <script src="js/jquery-1.10.2.js" type="text/javascript"></script>
   <script src="js/bootstrap.min.js" type="text/javascript"></script>

</html>